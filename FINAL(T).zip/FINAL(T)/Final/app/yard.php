<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class yard extends Model
{
    //
    protected $primaryKey='YardID';
    public $timestamps=false;
    protected $guarded=[];
    
}
