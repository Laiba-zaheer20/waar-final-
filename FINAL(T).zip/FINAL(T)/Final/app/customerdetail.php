<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class customerdetail extends Model
{
    //
    protected $primaryKey='CustomerID';
    public $timestamps=false;
}
