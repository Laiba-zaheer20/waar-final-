<?php echo e($slot); ?>

<?php /**PATH D:\xampp\htdocs\Final\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>