<!doctype html>
<html lang="en">
  <head>
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="csrf-token" content="<?php echo csrf_token(); ?>">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <style>
      .round{
          border-top-right-radius:5px;
          border-top-left-radius:5px;
          border-bottom-left-radius:5px;
          border-bottom-right-radius:5px;
          box-shadow:2px 2px 2px 2px;
      }
      </style>
  
  <body>
      <?php $__env->startSection('navbar'); ?>
      ##parent-placeholder-c63e3c1cfa2ff651ad4cfadea3e21265ffcf8ca3##
      <?php $__env->stopSection(); ?>

      <?php $__env->startSection('body'); ?>

      <style>
      .input-container {
              display: -ms-flexbox; /* IE10 */
              display: flex;
              width: 100%;
              margin-bottom: 15px;
      }
      .icon {
          padding: 10px;
          background: grey;
          color: white;

          width: 13%;
          margin-left:3%;
          text-align: center;
        }

      </style>
      
      <center>
        <div style="width:90%;height:700px;margin-top:40px">
            <center>
          <!-- <form method="post" action="<?php echo e(route('checkSignIn')); ?>">
          <?php echo csrf_field(); ?>      -->
            <div style="width:380px;height:600px;background-color:#ffbd2f;padding:10px" class="round">
                    <img src="../Capture.png" height="100px"/>
                 <div style="padding-top:50px;display:flex;flex-direction:column">
                    
                 
                     <div id="errors"></div>                  
                     <div class=" print-error-msg" style="display:none">
                        <ul></ul>
                      </div>

      
                        <label><strong>First Name</strong></label>
                        <div class="input-container">
                        <i class="fa fa-user icon"></i>   
                        <input  type="text" name="fname" id="fname" placeholder="  First Name" style="width:85%;margin-right:2%;" required />
                       </div>

                       <label><strong>Email Address</strong></label>
                       <div class="input-container">
                       <i class="fa fa-envelope icon"></i>
                      <input type="email" name="email" id="email" placeholder="  Email Address" style="width:85%;margin-right:2%;" required />
                        </div>

                        <label><strong>Password</strong></label>
                        <div class="input-container">
                        <i class="fa fa-key icon"></i>
                        <input type="password" name="password" id="password" placeholder="   Password"  style="width:85%;margin-right:2%;" />
                        </div>

                        <label><strong>Confirm Password</strong></label>
                        
                        <div class="input-container">
                        <i class="fa fa-key icon"></i>
                        <input type="password" name="password_confirmation" id="password_confirmation" placeholder="  Re-Enter Password" style="width:85%;margin-right:2%;" required />
                        </div>
                        
                        <button type="submit" id="send" class="btn btn-dark" style="margin-top:50px;width:40%;">Sign Up</button>
            
             </div>
            </div>
            </form>
            </center>
        </div>
</center>
<script>

$(document).ready(function(){
  $('#send').click(function(){
    
   $.ajax({
     type: "POST",
     data: {"_token": $('meta[name="csrf-token"]').attr('content'),
     "fname":$('#fname').val(),
     'email':$('#email').val(),
     "password":$('#password').val(),
     'password_confirmation':$('#password_confirmation').val(),
     
     },
     url: "<?php echo e(route('checkSignIn')); ?>",
     
     success: function(msg){
      if($.isEmptyObject(msg.error)){
       if(msg.key=='done!'){
        var targetUrl = "<?php echo e(route('login')); ?>";
        window.location = targetUrl;
      }
      }
      else{
        $(".key").css('display','none');
        printErrorMsg(msg.error);
     }
     }
  });
});

 function printErrorMsg (msg) {
            $(".print-error-msg").find("ul").html('');
            $(".print-error-msg").css('display','block');
            $.each( msg, function( key, value ) {
                $(".print-error-msg").find("ul").append('<li>'+value+'</li>');
            });
        }
    });
</script>

      <?php $__env->stopSection(); ?>
      <?php $__env->startSection('footer'); ?>
      ##parent-placeholder-d7eb6b340a11a367a1bec55e4a421d949214759f##
      <?php $__env->stopSection(); ?>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
   
    <script src="https://code.jquery.com/jquery-3.4.1.min.js" crossorigin="anonymous"></script>
     <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Final\resources\views/signup.blade.php ENDPATH**/ ?>