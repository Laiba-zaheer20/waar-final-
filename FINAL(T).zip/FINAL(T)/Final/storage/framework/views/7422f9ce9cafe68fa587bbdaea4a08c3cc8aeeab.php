<!doctype html>
<html lang="en">
  <head>
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  
  <body>
  
      <?php $__env->startSection('navbar'); ?>
      ##parent-placeholder-c63e3c1cfa2ff651ad4cfadea3e21265ffcf8ca3##
      <?php $__env->stopSection(); ?>

      <?php $__env->startSection('body'); ?>
      <center>

      <div style="width:80%;">
      <h1><?php echo e($cat->CategoryType); ?></h1>
      <div class="row">
      <?php $__currentLoopData = $cat->subcategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      
      <?php $__currentLoopData = $sub->product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <a href="<?php echo e(route('cart')); ?>?id=<?php echo e($product->ProductID); ?>" style="color:black">
            <div class="col-lg-3" style="margin:25px;">
            <div class="card" style="width: 18rem;width:200px;">
            <img src="<?php echo e($product->Image); ?>" class="card-img-top" alt="..." height="150px">
            <div class="card-body" style="height:100px">
                <h5 class="card-title"style="font-size:Medium"><?php echo e($product->ProductName); ?></h5>
                <div><?php echo e($product->ProductPrice); ?></div>
            </div>
            </div>
            </div>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <!-- Button trigger modal -->

      </center>
      <?php $__env->stopSection(); ?>

    
      <?php $__env->startSection('footer'); ?>
      ##parent-placeholder-d7eb6b340a11a367a1bec55e4a421d949214759f##
      <?php $__env->stopSection(); ?>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Final\resources\views/category.blade.php ENDPATH**/ ?>