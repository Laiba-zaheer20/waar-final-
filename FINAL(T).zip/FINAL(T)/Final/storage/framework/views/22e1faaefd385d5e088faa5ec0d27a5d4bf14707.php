<!doctype html>
<html lang="en">
  <head>
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  
  <body>
  <?php $__env->startSection('navbar'); ?>
  ##parent-placeholder-c63e3c1cfa2ff651ad4cfadea3e21265ffcf8ca3##
  <?php $__env->stopSection(); ?>

  <?php $__env->startSection('body'); ?>
  <center>
  <style>
table, th, td {
  border: 1px solid black;
}

input[type=text] {
  width: 20%;
  padding: 1px 1px;
  margin: 2px  ;
  box-sizing: border-box;
}

</style>
  <table>
  <thead>
  <th>
  S.No
  </th>
  <th>
  Product Name
  </th>
  <th>
  Size
  </th>
  <th>
  Quantity
  </th>
  <th>
  Price
  </th>
  <th>
  SubTotal
  </th>
  <th>
  Update
  </th>
  <th>
  Remove
  </th>
 
  </thead>
<tbody>
<?php $c=1;?>
<?php $total=0;?>
<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 

 
<tr>
<td>
<?php echo e($c); ?>

</td>
<td><?php echo e($row->name); ?></td>
<td>small</td>
<form action="<?php echo e(URL::to('update')); ?>" method='post'>
<?php echo e(csrf_field()); ?>

<td><input type='text' value='<?php echo e($row->quantity); ?>' name='qty'></input></td>
<td><?php echo e($row->price); ?></td>
<td><?php echo e($row->price*$row->quantity); ?></td>
<td>                    


 <input type='hidden' value=<?php echo e($row->id); ?> name='update'></input>
<input type="submit" value="update" style="background-color:green;color:white"></input>
</form></td>
<td>   <form action="<?php echo e(URL::to('delete')); ?>" method='post'>
                               <?php echo e(csrf_field()); ?>

                             
                               <input type='hidden' value=<?php echo e($row->id); ?> name='delete'></input>
                               <input type="submit" value="remove" style="background-color:red;color:white"></input>
                               </form></td>

</tr>
<?php $total=$total+($row->price*$row->quantity); ?>
<?php $c++;?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<tr>
<td colspan="5" align="right">Total</td>
<td align="right">$<?php echo e($total); ?></td>
</tr>




</tbody>
  </table>
  <form action="<?php echo e(URL::to('checkout')); ?>" method='post'>
                               <?php echo e(csrf_field()); ?>

                               <input type='submit' class="btn btn-primary" value='checkout'></button>
                               </form>

  
  <?php $__env->stopSection(); ?>



  <?php $__env->startSection('footer'); ?>
  ##parent-placeholder-d7eb6b340a11a367a1bec55e4a421d949214759f##
  <?php $__env->stopSection(); ?>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>
    
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Final\resources\views/cart.blade.php ENDPATH**/ ?>