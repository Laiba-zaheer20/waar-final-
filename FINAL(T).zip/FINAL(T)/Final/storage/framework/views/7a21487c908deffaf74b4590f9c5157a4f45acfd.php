<!doctype html>
<html lang="en">
  <head>
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  
    
  </head>

  <body style="background:">
      <center>
      <?php $__env->startSection('navbar'); ?>
      ##parent-placeholder-c63e3c1cfa2ff651ad4cfadea3e21265ffcf8ca3##
      <?php $__env->stopSection(); ?>

        <?php $__env->startSection('sidebar'); ?>
        <?php $__env->stopSection(); ?>
 
      <?php $__env->startSection('body'); ?>


<div style="width:90%;">
      <!-- carousel -->
      <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel" style="margin-top:50px">
    <ol class="carousel-indicators">
        <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
        <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
        <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
    </ol>
    <div class="carousel-inner">
        <div class="carousel-item active">
        <img src="https://images.unsplash.com/photo-1524464790303-b7f467781d29?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=667&q=80" height="350px" width="100%" class="d-block w-100" alt="...">
        <div class="carousel-caption d-none d-md-block">
            <h5 style="    font-weight: bold;text-transform: uppercase;"><strong>I don't design clothes. I design dreams.</strong></h5>
        </div>
        </div>
        <div class="carousel-item">
        <img src="https://images.unsplash.com/photo-1507434745378-235a6297156b?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=707&q=80" height="350px" width="100%" class="d-block w-100" alt="...">
        <div class="carousel-caption d-none d-md-block">
            <h5 style="    font-weight: bold;text-transform: uppercase;"><strong>"Fashions fade,style is eternal."</strong></h5>
        </div>
        </div>
        <div class="carousel-item">
        <img src="https://images.unsplash.com/photo-1552407396-f5e06cbf18a9?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=750&q=80" height="350px" width="100%" class="d-block w-100" alt="...">
        <div class="carousel-caption d-none d-md-block">
            <h5 style="    font-weight: bold;text-transform: uppercase;"><strong>"The joy of dressing is an art."</strong></h5>
        </div>
        </div>
        
    </div>
    <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
    </div>
      <!-- carousel -->
      </div>


<div style="margin-top:50px;display:flex;">

<i style="   display: block;height: 2px;background-color: #000; width: 40%;margin-top:13px;margin-left:60px"></i>
<h3 style="font-style:italic;font-family: Times New Roman, Times, serif;font-weight:bold">Most Selling</h3>
<i style="   display: block;height: 2px;background-color: #000; width: 40%;margin-top:13px"></i>
</div>
<div class="row" style="margin-left:45px">
<?php $i=0?>
<?php $__currentLoopData = $sell; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sell): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <?php if($i< 3): ?>
        <?php if($i==0): ?>

        <div class="card mb-3" style="max-width: 400px;margin:5px">
        <div class="row no-gutters">
            <div class="col-md-4">
            <img src="<?php echo e($sell->Image); ?>" class="card-img" alt="...">
            </div>
            <div class="col-md-8">
            <div class="card-body">
                <h5 class="card-title"><?php echo e($sell->ProductName); ?></h5>
               <p class="card-text"><small class="text-muted"><?php echo e($sell->ProductPrice); ?></small></p>
            </div>
            </div>
        </div>
        </div>
        
        <?php else: ?>
        <div class="card mb-3" style="max-width: 400px;margin:5px">
        <div class="row no-gutters">
            <div class="col-md-4">
            <img src="<?php echo e($sell->Image); ?>" class="card-img" alt="...">
            </div>
            <div class="col-md-8">
            <div class="card-body">
                <h5 class="card-title"><?php echo e($sell->ProductName); ?></h5>
               <p class="card-text"><small class="text-muted"><?php echo e($sell->ProductPrice); ?></small></p>
            </div>
            </div>
        </div>
        </div>

        
        <?php endif; ?>
        <?php $i++ ?>
        <?php else: ?>
            <?php break; ?>
        <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>



<div style="margin-top:50px;display:flex;">
<i style="   display: block;height: 2px;background-color: #000; width: 40%;margin-top:13px;margin-left:60px"></i>
<h3 style="font-style:italic;font-family: Times New Roman, Times, serif;font-weight:bold">New Arrivals</h3>
<i style="   display: block;height: 2px;background-color: #000; width: 40%;margin-top:13px"></i>
</div>
<div class="row" style="display:flex;margin-left:45px">
<?php $i=0?>
<?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $i++ ?>

        <div class="col-lg-2" style="margin:17px;box-shadow:2px 2px 2px 2px" >
        <div class="card" style="width: 12rem;">
        <a href="<?php echo e(route('cart')); ?>?id=<?php echo e($product->ProductID); ?>" style="color:black">
        <img src="<?php echo e($product->Image); ?>" class="card-img-top" alt="..." height="150px">
        <div class="card-body" style="height:110px">
            <h5 class="card-title"style="font-size:Medium;margin:10px"><?php echo e($product->ProductName); ?></h5>
            <h6 class="card-title"style="font-size:Medium;margin:10px"><?php echo e($product->ProductPrice); ?></h6>
       </a>
        </div>
        </div>
        </div>
        <?php if($i>=5) break; ?>
        
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<div style="margin-top:50px;display:flex;">

<i style="   display: block;height: 2px;background-color: #000; width: 43%;margin-top:13px;margin-left:60px"></i>
<h3 style="font-style:italic;font-family: Times New Roman, Times, serif;font-weight:bold">Sales</h3>
<i style="   display: block;height: 2px;background-color: #000; width: 43%;margin-top:13px"></i>
</div>
<div class="row" style="display:flex;margin-left:45px">
<?php $i=0?>
<?php $__currentLoopData = $sale; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $i++ ?>
        <div class="col-lg-2" style="margin:17px;box-shadow:2px 2px 2px 2px" >
        <div class="card" style="width: 12rem;">
        <a href="<?php echo e(route('cart')); ?>?id=<?php echo e($sale->ProductID); ?>" style="color:black">
        <img src="<?php echo e($sale->Image); ?>" class="card-img-top" alt="..." height="150px">
        <div class="card-body" style="height:110px">
        <h5 class="card-title"style="font-size:Medium;margin:10px"><?php echo e($sale->ProductName); ?></h5>
            <h6 class="card-title"style="font-size:Medium;margin:10px"><?php echo e($sale->ProductPrice); ?></h6>
       </a>
        </div>
        </div>
        </div>
        <?php if($i>=5) break; ?>
        
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
</center>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>
##parent-placeholder-d7eb6b340a11a367a1bec55e4a421d949214759f##
<?php $__env->stopSection(); ?>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\FINAL(T)\Final\resources\views/index.blade.php ENDPATH**/ ?>